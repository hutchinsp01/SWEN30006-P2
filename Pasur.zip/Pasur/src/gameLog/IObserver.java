package gameLog;

/**
 * Created by Paul Hutchins, Kian Dsouza, and Jade Siang in regard to SWEN30006 project 2
 */

public interface IObserver {
	public void update(String data);
}
